# Contributing

## Engineering rules

- Keep tools defensive, narrowly scoped, and read-only by default.
- Validate all MCP inputs inside the server; never trust model-generated parameters.
- Do not add arbitrary shell execution, unrestricted filesystem access, credential passthrough, or destructive response tools without a separate design and security review.
- Never log authorization headers, bearer tokens, raw alert payloads, or sensitive indicators.
- Add unit tests for validation and failure cases with every new tool.
- Update `docs/architecture.md`, `docs/threat-model.md`, and deployment instructions when trust boundaries change.

## Before opening a pull request

```bash
cargo fmt --all -- --check
cargo clippy --all-targets --all-features -- -D warnings
cargo test --all-targets
cargo audit
```

Describe changes, security implications, test evidence, operational impacts, and rollback plan. Do not include production data or secrets in tests, logs, fixtures, or screenshots.
