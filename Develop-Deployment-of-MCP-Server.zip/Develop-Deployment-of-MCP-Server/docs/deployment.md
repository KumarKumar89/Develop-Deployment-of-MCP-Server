# Development and deployment runbook

## 1. Development in GitHub Codespaces

Prerequisites: Rust 1.88 or newer, Cargo, Git, and optionally Docker. Open the repository in a Codespace, then run:

```bash
rustup component add rustfmt clippy
cargo generate-lockfile
cargo fmt --all -- --check
cargo clippy --all-targets --all-features -- -D warnings
cargo test --all-targets
cargo build --release
```

Commit `Cargo.lock` after generating it. Application builds should use the committed lockfile for repeatable dependency resolution.

## 2. Local stdio mode

```bash
MCP_TRANSPORT=stdio cargo run --release
```

The process waits for MCP JSON-RPC messages on stdin. It is not intended to be tested by typing arbitrary text into the terminal; use an MCP client or the MCP Inspector. Protocol output goes to stdout and diagnostic logs go to stderr.

### Claude Code local registration

From the repository root, run:

```bash
claude mcp add --scope user --transport stdio security-mcp -- "$PWD/target/release/cybersecurity-mcp-server"
claude mcp list
```

Build with `cargo build --release` first. Use your organization's approved scope and client policy; do not commit local credential-bearing configuration.

### Grok Build local registration

Grok Build can run a local stdio process. From the repository root:

```bash
grok mcp add security-mcp "$PWD/target/release/cybersecurity-mcp-server"
grok mcp doctor security-mcp
```

If your installed CLI uses the `grok` command, use `grok` (not `grok`'s similarly named tunnel tools). Grok remote MCP requires a reachable HTTP endpoint; local stdio is useful for local development only.

## 3. Secure shared HTTP deployment

The shared mode is appropriate when Claude and Grok must use the same running service. The sample uses Caddy for TLS and passes traffic to the app on the private Compose network.

1. Point a DNS name you control (for example, `mcp.example.com`) at the deployment host. Permit inbound TCP 80/443 for Caddy certificate issuance and HTTPS; do not publish port 8080.
2. Copy the example environment file and create a random token:

   ```bash
   cp .env.example .env
   openssl rand -hex 32
   ```

   Put the generated random value in `.env` as `MCP_BEARER_TOKEN` and replace `MCP_DOMAIN` with your DNS name. Restrict `.env` permissions (`chmod 600 .env`) and never commit it.
3. Start the stack:

   ```bash
   docker compose --env-file .env -f deploy/compose.yml up --build -d
   docker compose --env-file .env -f deploy/compose.yml logs --tail=100
   ```
4. Test from a trusted machine with the same token available in the environment:

   ```bash
   export MCP_BEARER_TOKEN='(load from your approved secret store)'
   export MCP_URL='https://mcp.example.com'
   ./scripts/smoke_test.sh
   ```
5. Rotate any token suspected of exposure. Recreate the service after updating the secret. For production, integrate with your organization's identity provider and replace the static bearer-token shim with a reviewed OAuth 2.1/OIDC resource-server implementation.

## 4. Configure Grok Build against the shared endpoint

Copy `.grok/config.toml.example` to `.grok/config.toml` in the working project and configure `MCP_DOMAIN` and `MCP_BEARER_TOKEN` through the Grok Build environment. Grok's MCP client supports remote Streamable HTTP endpoints and environment-variable expansion in configuration fields. Do not put a real token in a committed file.

Check connection and tool discovery with:

```bash
grok mcp doctor security_mcp
```

If the installed CLI is named `grok`, use `grok mcp doctor security_mcp`.

## 5. Configure Claude Code against the shared endpoint

Copy `config/claude-code.remote.example.json` to a local-only config file, set the service URL and fetch the bearer token from an approved secret store. Do not commit a filled-in config containing a token. Alternatively, use the current `claude mcp add --transport http` command and your organization's approved secret injection process. Verify with `claude mcp list`, then ask Claude to list the tools and perform a non-sensitive `get_security_baseline` call.

## 6. Operational release checklist

- [ ] Lockfile committed; CI format, Clippy, tests, and dependency audit pass.
- [ ] Repository is private unless security leadership approves public release.
- [ ] Branch protection and mandatory reviews enabled on `main`.
- [ ] Secret scanning and push protection enabled where available.
- [ ] HTTPS externally verified; MCP port is not directly published.
- [ ] Static token placed in a secret store, rotated, and excluded from logs.
- [ ] Egress denied by default; no unreviewed live integrations.
- [ ] Tool allowlists and user approval policies configured on both clients.
- [ ] Alert-handling runbooks, evidence retention, and privacy review approved.
- [ ] Rollback and incident-response exercises completed.
