# Initial threat model

## Assets

- Bearer token for the remote MCP endpoint.
- Security-alert metadata and indicators supplied by clients.
- Integrity of the server binary, dependencies, and deployment configuration.
- Availability of the endpoint and confidence in its tool outputs.

## Threats and starter controls

| Threat | Control in this starter | Production follow-up |
|---|---|---|
| Unauthenticated remote tool calls | HTTP mode requires bearer token on `/mcp` | OAuth 2.1/OIDC, token audience validation, identity-based authorization |
| Credential guessing or leak | Token must be at least 32 bytes; never log headers | Secret manager, rotation, rate limits, access monitoring, short-lived tokens |
| Large request body | 1 MiB HTTP body limit; tool-specific size limits | Gateway quotas and per-client rate limits |
| URL-based SSRF or beaconing | Indicator URL validation does not make outbound requests | Keep outbound egress denied unless a reviewed integration requires it |
| Prompt injection in alert content | Tool output is labeled as decision support; no arbitrary command tool | Treat external text as untrusted data; use structured schemas and allowlists |
| Model-triggered destructive response | No containment, shell, file-write, or account-management tools exist | Add explicit approvals, separate privileged tools, audit records, and rollback plans |
| Sensitive input exposure | Inputs are not written to application logs or storage; URL path/query/fragment are redacted from normalized output | Minimize sent data, define retention policy, redact telemetry end-to-end |
| Vulnerable dependency | CI runs `cargo audit`; Dependabot checks Cargo and GitHub Actions | Review advisories, pin dependencies, sign releases, SBOM and provenance |
| Compromised container | Non-root user, read-only root filesystem, dropped capabilities in Compose | Harden host, image provenance, policy enforcement, patch cadence, runtime monitoring |
| TLS misconfiguration | Caddy sample handles HTTPS for a real DNS name | Confirm certificates, HSTS at edge, TLS policy, firewall and network segmentation |

## Residual risks / non-goals

- A static bearer token is a bootstrap mechanism, not a complete enterprise identity system. Anyone who obtains it may invoke every exposed read-only tool.
- The health endpoint is public in the sample and reports only service liveness. Restrict it at the network edge if policy requires.
- Alert prioritization is a deterministic rules-based example, not a validated detection engine. It does not query live telemetry or replace analyst judgment.
- A syntax-valid indicator is not necessarily malicious, reachable, active, or attributable.
- This repository is a starter implementation. Complete a security review, integration tests, dependency review, privacy assessment, and incident-response exercise before production use.
